from Projects.Calculator.calculator_logic import ScientificCalculator

calc=ScientificCalculator()

print("Addition",calc.addition(2,3))
print("Subtraction",calc.sub(2,3))
print("Multiplicaion",calc.multi(2,3))
print("Division",calc.divide(2,3))
print("Power",calc.power(2,3))
print("Factorial",calc.fact(5))
print("Square root",calc.sqrt(9))